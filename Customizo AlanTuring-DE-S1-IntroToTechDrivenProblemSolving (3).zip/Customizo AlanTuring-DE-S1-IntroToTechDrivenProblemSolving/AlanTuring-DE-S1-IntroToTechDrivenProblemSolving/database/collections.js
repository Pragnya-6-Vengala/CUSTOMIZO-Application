module.exports = {
    USERS: 'users',
    REQUESTS: 'requests'
}