const apiControllers = module.exports;

apiControllers.authentication = require('./authentication');
apiControllers.user = require('./user');
apiControllers.app = require('./app');